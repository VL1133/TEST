package compolents;

public class AdminFooter {
}
